package com.itsupport.todolist.service.interfaces;

public interface AdminService {
    void deleteUserById(Long id);
}
